def main(student_list):
    print(student_list)